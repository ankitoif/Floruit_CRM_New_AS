﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIF.Cams.Model.ViewModels
{
    public class LayoutHeaderViewModel
    {
        public string LogoUrl { get; set; }        
        public string BranchAddress { get; set; }  
        public string AppLogoUrl { get; set; }  
    }
}
