﻿namespace OIF.Cams.CrossCutting
{
    public class CrossCutting_Constants
    {
        public const string AMPolicy = "AMPolicy";
        public const string BLPolicy = "BLPolicy";
        public const string RepositoryPolicy = "RepositoryPolicy";
        public const string ControllerPolicy = "ControllerPolicy";
    }
}
